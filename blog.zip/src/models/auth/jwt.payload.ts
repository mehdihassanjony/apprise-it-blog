export interface JwtPayload {
  email: string;
}
